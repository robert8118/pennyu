====================
Partner Credit Limit
====================

* Checks for all over due payment and already paid amount if the difference is positive and acceptable then Salesman able to confirm SO
 
* The credit the Partner has to paid.

* The amount of Sale Orders approved but not yet invoiced.

* The amount of the Sale Order to be approved, and compares it with the credit limit of the partner. If the credit limit is less it does not allow to approve the Sale Order

* If the Allow Over Credit is Checked then the System will not check for the credit limits, and it will allow that partner to override the limit.

Usage
=====

Bug Tracker
===========

Credits
=======

Contributors
------------

* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>

